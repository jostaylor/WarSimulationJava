Josh Taylor
jostaylor@chapman.edu
War Simulator

Instructions:
javac *.java
java Simulation _____ (an integer representing how many games you would like to simulate)
